# sACN Color Converter

Receives sACN (E1.31) fixtures with **16-bit Dimmer + CIE XY** colour
control from a lighting console (ETC EOS, grandMA, Chamsys, etc.),
solves the optimal mix of LED emitter channels to reproduce the
requested colour and luminance, and retransmits the result as sACN to
an LED driver or fixture.

Supports any multi-chip LED fixture — RGB, RGBW, RGBA, RGB+WW/CW, the
ETC Fos/4 Panel (8-chip), or any custom emitter combination you
define.  Optional intensity passthrough, 8-bit or 16-bit output, and
named control channels (strobe, curve, fan) are all supported.

---

## Requirements

- Python 3.9 or newer
- A lighting console that outputs CIE XY over sACN (e.g. ETC EOS)
- A network interface on the same subnet as your console and LED driver

---

## Installation

**From the wheel (recommended for most users):**

```bash
pip install sacn_color_converter-1.0.0-py3-none-any.whl
```

**From source:**

```bash
pip install .
```

**Development install (editable):**

```bash
pip install -e .
```

---

## Quick start

```bash
# First run — interactive setup wizard creates led_config.json
sacn-converter

# Re-use an existing config
sacn-converter

# Named config (useful when running multiple instances)
sacn-converter fos4.json

# Per-frame debug output
sacn-converter fos4.json --debug

# Run as a Python module
python -m sacn_color_converter fos4.json
```

Multiple instances on different universes run in parallel:

```bash
sacn-converter wash.json  &
sacn-converter cyc.json   &
```

---

## Input DMX layout (from console)

Six channels per fixture, always:

| Offset | Channel       | Notes                              |
|--------|---------------|------------------------------------|
| +0     | Dimmer MSB    | 16-bit dimmer, big-endian          |
| +1     | Dimmer LSB    |                                    |
| +2     | CIE X MSB     | 0–65535 maps to 0.0–1.0 (typical) |
| +3     | CIE X LSB     |                                    |
| +4     | CIE Y MSB     |                                    |
| +5     | CIE Y LSB     |                                    |

---

## Output DMX layout (to LED driver / fixture)

Determined by your fixture type and settings:

```
[Intensity]        optional; raw dimmer passthrough, no gamma
[LED chip 0]       8-bit (1 ch) or 16-bit MSB+LSB (2 ch)
[LED chip 1]
...
[Control ch 0]     held at 0; counted in footprint but never written
[Control ch 1]
...
```

**ETC Fos/4 Panel — Direct mode (12 ch/fixture):**

| Ch | Signal  |
|----|---------|
| 1  | Intensity |
| 2  | Deep Red  |
| 3  | Red       |
| 4  | Amber     |
| 5  | Lime      |
| 6  | Green     |
| 7  | Cyan      |
| 8  | Blue      |
| 9  | Indigo    |
| 10 | Strobe *(held 0)* |
| 11 | Curve  *(held 0)* |
| 12 | Fan    *(held 0)* |

---

## Config file reference

The wizard generates and saves a JSON config.  You can edit it directly:

```json
{
  "input_universe":    1,
  "output_universe":   2,
  "num_fixtures":      3,
  "input_start_addr":  1,
  "output_start_addr": 1,
  "bind_ip":           "192.168.1.50",
  "send_ip":           "192.168.1.50",
  "output_ip":         null,
  "has_intensity_ch":  true,
  "output_bit_depth":  8,
  "control_channels":  ["Strobe", "Curve", "Fan"],
  "xy_scale":          1.0,
  "output_gamma":      1.0,
  "leds": [
    {"name": "Deep Red", "x": 0.720, "y": 0.275, "flux":   8.0},
    {"name": "Red",      "x": 0.664, "y": 0.334, "flux":  42.0},
    {"name": "Amber",    "x": 0.570, "y": 0.425, "flux":  95.0},
    {"name": "Lime",     "x": 0.408, "y": 0.537, "flux": 137.0},
    {"name": "Green",    "x": 0.140, "y": 0.790, "flux": 117.0},
    {"name": "Cyan",     "x": 0.040, "y": 0.450, "flux":  82.0},
    {"name": "Blue",     "x": 0.130, "y": 0.063, "flux":  34.0},
    {"name": "Indigo",   "x": 0.157, "y": 0.018, "flux":   3.0}
  ]
}
```

| Key | Description |
|-----|-------------|
| `input_universe` / `output_universe` | sACN universe numbers (1–63999) |
| `num_fixtures` | Number of fixtures patched |
| `input_start_addr` / `output_start_addr` | 1-based DMX start address |
| `bind_ip` | IP of the NIC to receive on |
| `send_ip` | IP of the NIC to transmit from |
| `output_ip` | Unicast destination IP; `null` = multicast |
| `has_intensity_ch` | `true` if fixture expects an intensity channel first |
| `output_bit_depth` | `8` or `16` |
| `control_channels` | Names of trailing channels held at 0 |
| `xy_scale` | Full-scale mapping for XY values (1.0 for EOS/MA/Chamsys) |
| `output_gamma` | Output gamma curve (1.0 = linear) |
| `leds` | Array of emitter chips with CIE xy and relative flux |

---

## Calibration tips

- **CIE xy values** are datasheet starting points.  Measure your actual
  fixture with a spectrometer for best accuracy — emitter xy shifts with
  temperature and drive current.
- **Flux values** are relative to each other, not absolute.  Only the
  ratios between chips matter for the colour solver.
- **`--debug`** prints the solver weights per frame.  If any chip
  consistently hits 0 or 1.0, the requested colour is outside the
  fixture's gamut.
- **D65 reference white:** x=0.3127, y=0.3290

### ETC Fos/4 xy reference

Derived from Lumileds LUXEON C datasheet DS144 (350 mA, Tj=85°C):

| Chip | CIE x | CIE y | Source |
|------|-------|-------|--------|
| Deep Red | 0.720 | 0.275 | Derived, 660 nm peak |
| Red      | 0.664 | 0.334 | Derived, 629 nm dominant |
| Amber    | 0.570 | 0.425 | Datasheet Table 7, bin-20 centroid |
| Lime     | 0.408 | 0.537 | Datasheet Table 7, bin-10 centroid |
| Green    | 0.140 | 0.790 | Derived, 525 nm dominant |
| Cyan     | 0.040 | 0.450 | Derived, 498 nm dominant |
| Blue     | 0.130 | 0.063 | Derived, 472 nm dominant |
| Indigo   | 0.157 | 0.018 | Derived, 450 nm peak |

---

## Architecture notes

- **Receiver** — raw UDP socket with `SO_REUSEADDR` + `SO_REUSEPORT`
  so it coexists with sACNview or any other listener on port 5568.
  Multicast group joined on the chosen NIC via `IP_ADD_MEMBERSHIP`.
- **Sender** — sacn library used for TX only; a dedicated 44 Hz thread
  drives it independently of input arrival rate.
- **Solver** — `scipy.lsq_linear` bounded [0, 1], no `method=`
  argument (avoids the silent ValueError on scipy < 1.11).
- **Control channels** — written as 0 at startup and never touched,
  so the fixture's own strobe/curve/fan defaults are preserved.

---

## License

MIT — see `LICENSE`.
