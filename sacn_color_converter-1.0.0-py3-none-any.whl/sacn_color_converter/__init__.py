# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Mark Stuen
"""
sacn_color_converter
====================
sACN (E1.31) Intensity/XY → multi-chip LED colour space converter.

Receives 16-bit Dimmer + CIE X + CIE Y per fixture, solves the optimal
mix of LED emitter channels to reproduce the requested colour and
luminance, and retransmits the result as sACN.

Typical use
-----------
Run from the command line::

    sacn-converter                    # uses led_config.json
    sacn-converter fos4.json          # named config
    sacn-converter fos4.json --debug  # per-frame debug output

Or as a module::

    python -m sacn_color_converter fos4.json
"""

__version__ = "1.0.0"
__author__  = "sACN Color Converter"
