# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Mark Stuen
"""
colour.py
---------
Colour science utilities:
  - Build a 3×N LED gamut matrix from chip chromaticities + flux
  - Convert CIE xy + intensity to XYZ tristimulus
  - Bounded least-squares solver: XYZ target → per-chip weights (0–1)
  - DMX byte packing helpers
"""

import numpy as np
from scipy.optimize import lsq_linear


# ---------------------------------------------------------------------------
# Gamut matrix
# ---------------------------------------------------------------------------

def build_led_matrix(leds: list) -> np.ndarray:
    """
    Return a 3×N matrix M where column i = [X, Y, Z] of LED chip i at
    full output.  Normalised so the brightest chip has Y = 1.0, which
    keeps target XYZ values in the same 0–1 range as DMX intensity.

    Parameters
    ----------
    leds : list of dicts with keys  x (CIE), y (CIE), flux (relative lm)

    Returns
    -------
    M : np.ndarray, shape (3, N)
    """
    M = np.zeros((3, len(leds)))
    for i, led in enumerate(leds):
        x, y, flux = led["x"], led["y"], float(led["flux"])
        Y = flux
        X = (Y / y) * x
        Z = (Y / y) * (1.0 - x - y)
        M[:, i] = [X, Y, Z]
    peak_y = M[1, :].max()
    if peak_y > 0:
        M /= peak_y
    return M


# ---------------------------------------------------------------------------
# CIE xy → XYZ
# ---------------------------------------------------------------------------

def xy_intensity_to_XYZ(x: float, y: float, intensity: float) -> np.ndarray:
    """
    Convert CIE xy chromaticity coordinates and a photometric intensity
    (0–1) to XYZ tristimulus values.

    Returns a zero vector when y or intensity is negligibly small.
    """
    if y < 1e-7 or intensity < 1e-7:
        return np.zeros(3)
    Y = float(intensity)
    return np.array([(Y / y) * x, Y, (Y / y) * (1.0 - x - y)])


# ---------------------------------------------------------------------------
# Solver
# ---------------------------------------------------------------------------

def solve_led_weights(target_XYZ: np.ndarray, M: np.ndarray,
                      has_intensity_ch: bool = False) -> np.ndarray:
    """
    Solve for per-chip weights given a target XYZ tristimulus value.

    Two modes depending on whether the fixture has a dedicated intensity
    (master dimmer) channel:

    has_intensity_ch = False  [RGB strips, fixtures without a master ch]
    ----------------------------------------------------------------
    Bounded least-squares: find w ∈ [0, 1]^N  s.t.  M @ w ≈ target_XYZ.
    The chips must reproduce both colour AND brightness by themselves.
    For in-gamut colours this is exact; for out-of-gamut colours scipy
    finds the minimum-XYZ-error point inside the unit hypercube.

    has_intensity_ch = True   [ETC Fos/4 Direct, similar fixtures]
    ----------------------------------------------------------------
    Colour-only solve: the separate Int channel already carries the
    master dimmer, so the chip channels encode COLOUR DIRECTION only.

    Problem with the naive bounded approach:
      On wide-gamut fixtures (Fos/4) the peak-flux chip (lime, 2260 fc)
      is ~13× brighter than the reddest chip (deep red, 169 fc).  A pure
      deep-red target at intensity=1.0 asks for Y=1.0 which deep-red
      alone can only supply as 0.075.  The bounded solver then turns on
      amber + lime + green to compensate the missing Y, producing warm
      white instead of red.  The same problem makes off-spectrum colours
      (x+y near 1, tiny y) produce all-255 output.

    Fix — NNLS + normalise:
      1. Solve with lower bound 0 and NO upper bound (NNLS).  This finds
         the non-negative combination that best matches the target colour
         *direction* without clipping the dominant chip.
      2. Normalise so max(w) = 1.0.  Deep red at any intensity returns
         w_DR = 1.0, everything else = 0.  Off-spectrum colours map to
         whichever chip(s) best approximate that spectral direction.
      3. The Int channel carries the actual dimmer; the fixture multiplies
         Int × chip_mix internally.

    Parameters
    ----------
    target_XYZ      : np.ndarray, shape (3,)
    M               : np.ndarray, shape (3, N)  — LED gamut matrix
    has_intensity_ch: bool — True for Int-channel fixtures

    Returns
    -------
    w : np.ndarray, shape (N,), values in [0, 1]
    """
    if target_XYZ.max() < 1e-9:
        return np.zeros(M.shape[1])

    try:
        if has_intensity_ch:
            # --- Colour-direction solve (NNLS, then normalise) ---
            # Upper bound = inf so the dominant chip is never clipped.
            result = lsq_linear(M, target_XYZ, bounds=(0.0, np.inf))
            w = np.clip(result.x, 0.0, None)
            peak = w.max()
            if peak < 1e-9:
                return np.zeros(M.shape[1])
            return w / peak            # normalise: brightest chip = 1.0

        else:
            # --- Standard bounded solve (colour + brightness) ---
            return np.clip(
                lsq_linear(M, target_XYZ, bounds=(0.0, 1.0)).x,
                0.0, 1.0
            )

    except Exception as e:
        print(f"\n  SOLVER ERROR: {e}", flush=True)
        return np.zeros(M.shape[1])


# ---------------------------------------------------------------------------
# DMX helpers
# ---------------------------------------------------------------------------

def unpack16(high: int, low: int) -> float:
    """16-bit big-endian MSB/LSB pair → float 0–1."""
    return ((int(high) << 8) | int(low)) / 65535.0


def write_channel(buf: list, pos: int, value_0_1: float,
                  bit_depth: int, gamma: float = 1.0) -> int:
    """
    Write one controlled DMX channel (intensity or LED chip) into buf.

    8-bit  : writes 1 byte  at buf[pos],                returns pos + 1
    16-bit : writes MSB then LSB at buf[pos], buf[pos+1], returns pos + 2

    Parameters
    ----------
    buf        : mutable list of ints, length 512
    pos        : 0-based index into buf
    value_0_1  : normalised value in [0, 1]
    bit_depth  : 8 or 16
    gamma      : output gamma (applied before quantisation)

    Returns
    -------
    next_pos : int
    """
    v = float(np.clip(value_0_1, 0.0, 1.0))
    if gamma != 1.0:
        v = v ** (1.0 / gamma)
    if bit_depth == 16:
        val = int(round(v * 65535))
        if pos + 1 < 512:
            buf[pos]     = (val >> 8) & 0xFF
            buf[pos + 1] =  val       & 0xFF
        return pos + 2
    else:
        if pos < 512:
            buf[pos] = int(round(v * 255))
        return pos + 1
